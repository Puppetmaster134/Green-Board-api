<?php
echo getenv("RDS_DB_NAME");
?>